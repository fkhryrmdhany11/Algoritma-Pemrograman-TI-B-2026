while True:
    total = int(input('Masukkan Total Pembelian: '))
    jumlah = int(input('Masukkan Jumlah Uang: '))

    kembalian = jumlah - total

    if kembalian == 0:
        print('Uang pas, tidak ada kembalian')
    else:
        break

print(f'Kembalian Anda : Rp.{kembalian}')