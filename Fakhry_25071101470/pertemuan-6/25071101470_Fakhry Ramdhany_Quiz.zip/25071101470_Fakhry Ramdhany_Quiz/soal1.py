Film = [["Danur", 50000], 
        ["Inside Out 2", 45000],
        ["KNY", 45000],
        ["Avatar", 50000],
        ["Pertaruhan", 40000]]

for i in range(len(Film)):
    print(f'Film {i+1}: {Film[i][0]}')
print('')

dipilih = int(input('Masukkan Film yang mau Dipilih: ')) - 1
if dipilih < 5:
    print(f'Film {dipilih + 1}: {Film[dipilih][0]} Dengan Harga Rp.{Film[dipilih][1]}')
else:
    print('Error')