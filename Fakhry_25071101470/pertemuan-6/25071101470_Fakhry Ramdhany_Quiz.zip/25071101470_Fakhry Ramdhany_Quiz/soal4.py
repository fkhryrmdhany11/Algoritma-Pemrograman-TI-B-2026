hari = int(input("Masukkan banyak hari: "))
film = int(input("Masukkan banyak film: "))

data = []
for i in range(hari):
    print(f'Hari ke-{i+1}:')
    tiket = []
    for j in range(film):
        jumlah = int(input(f'Jumlah Penjualan Tiket Film ke-{j+1}: '))
        tiket.append(jumlah)
    data.append(tiket)

print(data)