Film = [["Danur", 50000], 
        ["Inside Out 2", 45000],
        ["KNY", 45000],
        ["Avatar", 50000],
        ["Pertaruhan", 40000]]

for i in range(len(Film)):
    print(f'Film {i+1}. {Film[i][0]}')
print('')

list_Film = []
while True:
    pilihan = int(input('Pilih Film (0 untuk berhenti): '))
    if pilihan == 0:
        break
    Tiket = int(input('Masukkan Jumlah Tiket yang mau Dibeli: '))
    Harga = Film[pilihan - 1][1]
    Nama = Film[pilihan - 1][0]
    list_Film.append([Nama, Tiket, Harga * Tiket])

for i in range(len(list_Film)):
    print(f'{i+1}. {list_Film[i][0]} X {list_Film[i][1]} = {list_Film[i][2]}')
